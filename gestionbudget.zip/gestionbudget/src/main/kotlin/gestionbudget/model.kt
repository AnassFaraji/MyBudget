package gestionbudget

// Modèle pour les Transactions (Dépenses)
class Transaction(
    val depense: Double,
    val description: String,
    val date: String,
    val categorie: String
)

// Modèle pour les Revenus
class Revenue(
    val montant: Double,
    val description: String,
    val date: String,
    val categorie: String
)

object GestionBudget {
    private val transactions = mutableListOf<Transaction>()
    private val revenus = mutableListOf<Revenue>()

    fun initializeData() {
        // Revenus en dur
        revenus.add(Revenue(3000.0, "Salaire", "2024-12-01", "Salaire"))

        // Dépenses en dur
        transactions.add(Transaction(800.0, "Loyer", "2024-12-05", "Loyer"))
        transactions.add(Transaction(15.0, "Abonnement Netflix", "2024-12-03", "Abonnement"))
        transactions.add(Transaction(30.0, "Abonnement Basic-fit", "2024-12-03", "Abonnement"))
        transactions.add(Transaction(35.0, "Abonnement Internet", "2024-12-03", "Abonnement"))
        transactions.add(Transaction(15.0, "Abonnement téléphone", "2024-12-03", "Abonnement"))
        transactions.add(Transaction(200.0, "Crédit Voiture", "2024-12-07", "Crédit"))
        transactions.add(Transaction(150.0, "Courses Alimentaires", "2024-12-10", "Alimentation"))
    }

    // Gestion des Transactions (Dépenses)

    // Ajouter une transaction
    fun addTransaction(newTransaction: Transaction) {
        require(newTransaction.depense >= 0) { "La dépense doit être positive ou égale à zéro." }
        transactions.add(newTransaction)
    }

    // Supprimer une transaction par index
    fun removeTransaction(index: Int) {
        if (index in transactions.indices) {
            transactions.removeAt(index)
        }
    }

    // Mettre à jour une transaction par index
    fun updateTransaction(index: Int, updatedTransaction: Transaction) {
        if (index in transactions.indices) {
            transactions[index] = updatedTransaction
        }
    }

    // Récupérer toutes les transactions
    fun getTransactions(): List<Transaction> {
        return transactions.toList()
    }

    // Récupérer les transactions d'une catégorie spécifique
    fun getTransactionsByCategory(category: String): List<Transaction> {
        return transactions.filter { it.categorie == category }
    }

    // Répartition des dépenses par catégorie
    fun getExpensesByCategory(): Map<String, Double> {
        return transactions.groupBy { it.categorie }
            .mapValues { (_, list) -> list.sumOf { it.depense } }
    }

    // Calcul du total des dépenses
    fun getTotalExpenses(): Double {
        return transactions.sumOf { it.depense }
    }

    // Gestion des Revenus

    // Ajouter un revenu
    fun addRevenue(newRevenue: Revenue) {
        require(newRevenue.montant >= 0) { "Le montant du revenu doit être positif ou égal à zéro." }
        revenus.add(newRevenue)
    }

    // Supprimer un revenu par index
    fun removeRevenue(index: Int) {
        if (index in revenus.indices) {
            revenus.removeAt(index)
        }
    }

    // Mettre à jour un revenu par index
    fun updateRevenue(index: Int, updatedRevenue: Revenue) {
        if (index in revenus.indices) {
            revenus[index] = updatedRevenue
        }
    }

    // Récupérer tous les revenus
    fun getRevenues(): List<Revenue> {
        return revenus.toList()
    }

    // Récupérer les revenus d'une catégorie spécifique
    fun getRevenuesByCategory(category: String): List<Revenue> {
        return revenus.filter { it.categorie == category }
    }

    // Répartition des revenus par catégorie
    fun getRevenuesByCategory(): Map<String, Double> {
        return revenus.groupBy { it.categorie }
            .mapValues { (_, list) -> list.sumOf { it.montant } }
    }

    // Calcul du total des revenus
    fun getTotalRevenues(): Double {
        return revenus.sumOf { it.montant }
    }

    // Calcul du bilan
    fun calculateBalance(): Double {
        return getTotalRevenues() - getTotalExpenses()
    }
}
