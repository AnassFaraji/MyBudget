package gestionbudget

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.center
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer


@Composable
fun GestionDesDepensesView() {
    var montant by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var categorie by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("") }
    var transactions by remember { mutableStateOf(GestionBudget.getTransactions()) }
    var filteredTransactions by remember { mutableStateOf(transactions) }
    var selectedTransactionIndex by remember { mutableStateOf(-1) } // Index pour modification
    var totalFilteredExpenses by remember { mutableStateOf(0.0) } // Total des dépenses filtrées
    var totalAllExpenses by remember { mutableStateOf(0.0) } // Total de toutes les dépenses

    // Recalculer les totaux chaque fois que la liste change
    LaunchedEffect(transactions, selectedCategory) {
        filteredTransactions = if (selectedCategory.isNotEmpty()) {
            GestionBudget.getTransactionsByCategory(selectedCategory)
        } else {
            transactions
        }
        totalFilteredExpenses = filteredTransactions.sumOf { it.depense }
        totalAllExpenses = transactions.sumOf { it.depense }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Titre Principal
        Text(
            "Gestion des Dépenses",
            style = MaterialTheme.typography.h4,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Totaux des Dépenses
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Card(
                elevation = 4.dp,
                modifier = Modifier.weight(1f).padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Total de Toutes les Dépenses : ${totalAllExpenses}€",
                        style = MaterialTheme.typography.h6,
                        fontSize = 18.sp
                    )
                }
            }

            Card(
                elevation = 4.dp,
                modifier = Modifier.weight(1f).padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Total des Dépenses Filtrées : ${totalFilteredExpenses}€",
                        style = MaterialTheme.typography.h6,
                        fontSize = 18.sp
                    )
                }
            }
        }
        // Formulaire pour ajouter ou modifier une dépense
        Card(
            elevation = 4.dp,
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    if (selectedTransactionIndex == -1) "Ajouter une Dépense" else "Modifier une Dépense",
                    style = MaterialTheme.typography.h6
                )
                Spacer(modifier = Modifier.height(8.dp))
                TextField(
                    value = montant,
                    onValueChange = { montant = it },
                    label = { Text("Montant (€)") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(modifier = Modifier.height(8.dp))
                TextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                TextField(
                    value = categorie,
                    onValueChange = { categorie = it },
                    label = { Text("Catégorie") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(16.dp))

                Row {
                    Button(
                        onClick = {
                            val montantDouble = montant.toDoubleOrNull() ?: 0.0
                            if (selectedTransactionIndex == -1) {
                                GestionBudget.addTransaction(
                                    Transaction(
                                        montantDouble,
                                        description,
                                        LocalDate.now().toString(),
                                        categorie
                                    )
                                )
                            } else {
                                GestionBudget.updateTransaction(
                                    selectedTransactionIndex,
                                    Transaction(
                                        montantDouble,
                                        description,
                                        LocalDate.now().toString(),
                                        categorie
                                    )
                                )
                                selectedTransactionIndex = -1
                            }
                            transactions = GestionBudget.getTransactions()
                            montant = ""
                            description = ""
                            categorie = ""
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (selectedTransactionIndex == -1) "Ajouter" else "Modifier")
                    }
                    if (selectedTransactionIndex != -1) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                selectedTransactionIndex = -1
                                montant = ""
                                description = ""
                                categorie = ""
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.error)
                        ) {
                            Text("Annuler")
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Filtrer par catégorie
        Card(
            elevation = 4.dp,
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Filtrer les Dépenses par Catégorie", style = MaterialTheme.typography.h6)
                Spacer(modifier = Modifier.height(8.dp))
                TextField(
                    value = selectedCategory,
                    onValueChange = { selectedCategory = it },
                    label = { Text("Catégorie") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Liste des Transactions
        Card(
            elevation = 4.dp,
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Liste des Dépenses", style = MaterialTheme.typography.h6)
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.heightIn(max = 400.dp) // Limite la hauteur pour éviter les débordements
                ) {
                    itemsIndexed(filteredTransactions) { index, transaction ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(transaction.description)
                                Text("${transaction.depense}€ | ${transaction.categorie} | ${transaction.date}")
                            }
                            Row {
                                Button(onClick = {
                                    selectedTransactionIndex = index
                                    montant = transaction.depense.toString()
                                    description = transaction.description
                                    categorie = transaction.categorie
                                }) {
                                    Text("Modifier")
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        GestionBudget.removeTransaction(index)
                                        transactions = GestionBudget.getTransactions()
                                    },
                                    colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.error)
                                ) {
                                    Text("Supprimer")
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))


    }
}

@Composable
fun GestionDesRevenusView() {
    var montant by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var categorie by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("") }
    var revenus by remember { mutableStateOf(GestionBudget.getRevenues()) }
    var filteredRevenus by remember { mutableStateOf(revenus) }
    var selectedRevenueIndex by remember { mutableStateOf(-1) } // Index pour modification
    var totalFilteredRevenues by remember { mutableStateOf(0.0) } // Total des revenus filtrés
    var totalAllRevenues by remember { mutableStateOf(0.0) } // Total de tous les revenus

    // Recalculer les totaux chaque fois que la liste change
    LaunchedEffect(revenus, selectedCategory) {
        filteredRevenus = if (selectedCategory.isNotEmpty()) {
            GestionBudget.getRevenuesByCategory(selectedCategory)
        } else {
            revenus
        }
        totalFilteredRevenues = filteredRevenus.sumOf { it.montant }
        totalAllRevenues = revenus.sumOf { it.montant }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Titre Principal
        Text(
            "Gestion des Revenus",
            style = MaterialTheme.typography.h4,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Totaux des Revenus
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Card(
                elevation = 4.dp,
                modifier = Modifier.weight(1f).padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Total de Tous les Revenus : ${totalAllRevenues}€",
                        style = MaterialTheme.typography.h6,
                        fontSize = 18.sp
                    )
                }
            }

            Card(
                elevation = 4.dp,
                modifier = Modifier.weight(1f).padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Total des Revenus Filtrés : ${totalFilteredRevenues}€",
                        style = MaterialTheme.typography.h6,
                        fontSize = 18.sp
                    )
                }
            }
        }

        // Formulaire pour ajouter ou modifier un revenu
        Card(
            elevation = 4.dp,
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    if (selectedRevenueIndex == -1) "Ajouter un Revenu" else "Modifier un Revenu",
                    style = MaterialTheme.typography.h6
                )
                Spacer(modifier = Modifier.height(8.dp))
                TextField(
                    value = montant,
                    onValueChange = { montant = it },
                    label = { Text("Montant (€)") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(modifier = Modifier.height(8.dp))
                TextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                TextField(
                    value = categorie,
                    onValueChange = { categorie = it },
                    label = { Text("Catégorie") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(16.dp))

                Row {
                    Button(
                        onClick = {
                            val montantDouble = montant.toDoubleOrNull() ?: 0.0
                            if (selectedRevenueIndex == -1) {
                                GestionBudget.addRevenue(
                                    Revenue(
                                        montantDouble,
                                        description,
                                        LocalDate.now().toString(),
                                        categorie
                                    )
                                )
                            } else {
                                GestionBudget.updateRevenue(
                                    selectedRevenueIndex,
                                    Revenue(
                                        montantDouble,
                                        description,
                                        LocalDate.now().toString(),
                                        categorie
                                    )
                                )
                                selectedRevenueIndex = -1
                            }
                            revenus = GestionBudget.getRevenues()
                            montant = ""
                            description = ""
                            categorie = ""
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (selectedRevenueIndex == -1) "Ajouter" else "Modifier")
                    }
                    if (selectedRevenueIndex != -1) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                selectedRevenueIndex = -1
                                montant = ""
                                description = ""
                                categorie = ""
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.error)
                        ) {
                            Text("Annuler")
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Filtrer par catégorie
        Card(
            elevation = 4.dp,
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Filtrer les Revenus par Catégorie", style = MaterialTheme.typography.h6)
                Spacer(modifier = Modifier.height(8.dp))
                TextField(
                    value = selectedCategory,
                    onValueChange = { selectedCategory = it },
                    label = { Text("Catégorie") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Liste des Revenus
        Card(
            elevation = 4.dp,
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Liste des Revenus", style = MaterialTheme.typography.h6)
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.heightIn(max = 400.dp) // Limite la hauteur pour éviter les débordements
                ) {
                    itemsIndexed(filteredRevenus) { index, revenu ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(revenu.description)
                                Text("${revenu.montant}€ | ${revenu.categorie} | ${revenu.date}")
                            }
                            Row {
                                Button(onClick = {
                                    selectedRevenueIndex = index
                                    montant = revenu.montant.toString()
                                    description = revenu.description
                                    categorie = revenu.categorie
                                }) {
                                    Text("Modifier")
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        GestionBudget.removeRevenue(index)
                                        revenus = GestionBudget.getRevenues()
                                    },
                                    colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.error)
                                ) {
                                    Text("Supprimer")
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

    }
}

@Composable
fun BilanView() {
    // Calculs des totaux
    val totalDepenses = GestionBudget.getTotalExpenses()
    val totalRevenus = GestionBudget.getTotalRevenues()
    val reste = totalRevenus - totalDepenses // Argent restant

    // Vérification pour éviter des calculs erronés
    val total = totalDepenses + totalRevenus
    val depenseProportion = if (total > 0) totalDepenses / total else 0.0
    val revenuProportion = if (total > 0) totalRevenus / total else 0.0

    // Animation de progression
    val animatedSweepAngle = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        animatedSweepAngle.animateTo(
            targetValue = 360f,
            animationSpec = tween(durationMillis = 1500, easing = LinearOutSlowInEasing)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Titre principal
        Text(
            "Bilan Financier",
            style = MaterialTheme.typography.h4,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Carte pour les totaux
        Card(
            elevation = 4.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    "Total des Revenus : ${"%.2f".format(totalRevenus)}€",
                    style = MaterialTheme.typography.h6,
                    color = Color.Blue
                )
                Text(
                    "Total des Dépenses : ${"%.2f".format(totalDepenses)}€",
                    style = MaterialTheme.typography.h6,
                    color = Color.Red
                )
                Text(
                    "Reste Disponible : ${"%.2f".format(reste)}€",
                    style = MaterialTheme.typography.h6,
                    color = if (reste >= 0) Color.Green else Color.Red
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Carte pour le graphe circulaire
        Card(
            elevation = 4.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Canvas(modifier = Modifier.size(250.dp)) {
                    val strokeWidth = 40f // Largeur de l'anneau
                    val radius = size.minDimension / 2 - strokeWidth / 2
                    val center = size.center

                    // Angles animés des arcs
                    val sweepAngleDepenses =
                        if (reste >= 0) animatedSweepAngle.value * depenseProportion.toFloat()
                        else animatedSweepAngle.value
                    val sweepAngleRevenus =
                        if (reste >= 0) animatedSweepAngle.value * revenuProportion.toFloat()
                        else 0f

                    // Dessiner les dépenses (arc rouge)
                    drawArc(
                        color = Color.Red,
                        startAngle = -90f, // Angle de départ en haut
                        sweepAngle = sweepAngleDepenses,
                        useCenter = false, // Style "donut"
                        style = Stroke(width = strokeWidth),
                        topLeft = center - Offset(radius, radius),
                        size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2)
                    )

                    // Dessiner les revenus (arc vert), seulement si les finances sont positives
                    if (reste >= 0) {
                        drawArc(
                            color = Color.Green,
                            startAngle = -90f + sweepAngleDepenses, // Commence là où s'arrêtent les dépenses
                            sweepAngle = sweepAngleRevenus,
                            useCenter = false,
                            style = Stroke(width = strokeWidth),
                            topLeft = center - Offset(radius, radius),
                            size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Légende du Graphe
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Canvas(modifier = Modifier.size(16.dp)) {
                            drawRect(color = Color.Red)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Dépenses (${(depenseProportion * 100 + 1).toInt()}%)",
                            style = MaterialTheme.typography.body1
                        )
                    }
                    if (reste >= 0) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Canvas(modifier = Modifier.size(16.dp)) {
                                drawRect(color = Color.Green)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Revenus (${(revenuProportion * 100).toInt()}%)",
                                style = MaterialTheme.typography.body1
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Carte pour l'analyse financière
        Card(
            elevation = 4.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Analyse Financière", style = MaterialTheme.typography.h6)
                Spacer(modifier = Modifier.height(8.dp))

                if (reste >= 0) {
                    Text(
                        "Félicitations ! Vous avez un solde positif. Vous pourriez économiser ${"%.2f".format(reste)}€ ou investir cet argent dans vos projets.",
                        style = MaterialTheme.typography.body1,
                        color = Color.Green
                    )
                } else {
                    Text(
                        "Attention ! Vos dépenses dépassent vos revenus de ${"%.2f".format(-reste)}€. Pensez à réduire vos dépenses ou à augmenter vos revenus.",
                        style = MaterialTheme.typography.body1,
                        color = Color.Red
                    )
                }
            }
        }
    }
}








@Composable
fun MainView() {
    var currentSection by remember { mutableStateOf("Dépenses") } // État pour suivre la section active

    Column(modifier = Modifier.fillMaxSize()) {
        // Barre de navigation
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = { currentSection = "Dépenses" },
                colors = if (currentSection == "Dépenses") {
                    ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.primary)
                } else {
                    ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.surface)
                }
            ) {
                Text("Dépenses")
            }
            Button(
                onClick = { currentSection = "Revenus" },
                colors = if (currentSection == "Revenus") {
                    ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.primary)
                } else {
                    ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.surface)
                }
            ) {
                Text("Revenus")
            }
            Button(
                onClick = { currentSection = "Bilan" },
                colors = if (currentSection == "Bilan") {
                    ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.primary)
                } else {
                    ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.surface)
                }
            ) {
                Text("Bilan")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Afficher la section correspondante
        when (currentSection) {
            "Dépenses" -> GestionDesDepensesView()
            "Revenus" -> GestionDesRevenusView()
            "Bilan" -> BilanView()
        }
    }
}